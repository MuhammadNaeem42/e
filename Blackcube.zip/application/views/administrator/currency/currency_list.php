<div class="panel-body">
    <div class="table-responsive">
        <table id="datas-table" class="table table-striped table-bordered">
            <thead>
                <tr>
                    <th class="text-center">S.No</th>
                    <th class="text-center">Currency Name</th>
                    <th class="text-center">Currency Symbol</th>
                    <th class="text-center">Type</th>
                    <th class="text-center">Asset Type</th>
                    <th class="text-center">Sort Order</th>
                    <th class="text-center">Status</th>
                    <th class="text-center">Action</th>
                </tr>
            </thead>
            <tbody>               
            </tbody>
        </table>
    </div>
</div>