<?php 
  $this->load->view('front/common/header');
?>
<div class="jb_middle_content jb_learndetails_page">
    <div class="container">
      <div class="row jb_ln_list_rows">
  
 <div class=" col-xl-8">
 <div class="jb_ln_det_main">
 <div class="jb_ln_list_hdng">KYC Verfication Steps</div>
 <div class="jb_ln_list_det_p">Vivamus gravida ligula et porta tempor. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Integer venenatis ultricies lobortis. Quisque augue nisi, elementum ac quam a, convallis congue nunc. Quisque euismod libero massa, ut consectetur enim facilisis id. Praesent nec facilisis odio. Sed at bibendum odio, nec consectetur ex. Suspendisse vel rutrum risus. Phasellus commodo, orci vitae cursus congue, velit orci scelerisque tortor, hendrerit tincidunt nisl lacus eget orci. Duis pretium urna quis nibh porttitor, a dignissim massa efficitur. Aenean libero metus, dictum egestas bibendum sed, sollicitudin at libero. Donec eget lectus sollicitudin, venenatis neque eu, euismod justo.                               </div>
 <img src="assets/images/learn-img.jpg" class="jb_ln_list_det_img">
 <div class="jb_ln_list_det_p">Vivamus gravida ligula et porta tempor. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Integer venenatis ultricies lobortis. Quisque augue nisi, elementum ac quam a, convallis congue nunc. Quisque euismod libero massa, ut consectetur enim facilisis id. Praesent nec facilisis odio. Sed at bibendum odio, nec consectetur ex. Suspendisse vel rutrum risus. Phasellus commodo, orci vitae cursus congue, velit orci scelerisque tortor, hendrerit tincidunt nisl lacus eget orci. Duis pretium urna quis nibh porttitor, a dignissim massa efficitur. Aenean libero metus, dictum egestas bibendum sed, sollicitudin at libero. Donec eget lectus sollicitudin, venenatis neque eu, euismod justo.                               </div>
 <img src="assets/images/learn-img.jpg" class="jb_ln_list_det_img">

 <div class="jb_ln_list_det_p">Vivamus gravida ligula et porta tempor. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Integer venenatis ultricies lobortis. Quisque augue nisi, elementum ac quam a, convallis congue nunc. Quisque euismod libero massa, ut consectetur enim facilisis id. Praesent nec facilisis odio. Sed at bibendum odio, nec consectetur ex. Suspendisse vel rutrum risus. Phasellus commodo, orci vitae cursus congue, velit orci scelerisque tortor, hendrerit tincidunt nisl lacus eget orci. Duis pretium urna quis nibh porttitor, a dignissim massa efficitur. Aenean libero metus, dictum egestas bibendum sed, sollicitudin at libero. Donec eget lectus sollicitudin, venenatis neque eu, euismod justo.                               </div>


 </div>
 </div>
 <div class=" col-xl-4">
    <div class="jb_ln_list_hdng">Categories</div>
    <div class="jb_ln_list_ul">
    <a href="" class="jb_ln_list_li">Blockchain</a>
    <a href="" class="jb_ln_list_li">ICO</a>
    <a href="" class="jb_ln_list_li">NFT</a>
    <a href="" class="jb_ln_list_li">Cryptocurrency</a>
    <a href="" class="jb_ln_list_li">Bitcoin</a>
    <a href="" class="jb_ln_list_li">ETH</a>
    <a href="" class="jb_ln_list_li">Staking</a>
    <a href="" class="jb_ln_list_li">Margin Trading</a>
    <a href="" class="jb_ln_list_li">P2P</a>
   


    </div>


    <div class="jb_ln_list_hdng">Recommended</div>


    <div class="jb_ln_list_sid_out">
    <a href="#" class="jb_ln_list_sid_li">
       <img src="assets/images/learn-img.jpg" class="jb_ln_list_sid_li_img">
       <div class="jb_ln_list_sid_li_txt">According to closed source code, iOS only functions</div>
    </a>
    <a href="#" class="jb_ln_list_sid_li">
       <img src="assets/images/learn-img.jpg" class="jb_ln_list_sid_li_img">
       <div class="jb_ln_list_sid_li_txt">According to closed source code, iOS only functions</div>
    </a>
    <a href="#" class="jb_ln_list_sid_li">
       <img src="assets/images/learn-img.jpg" class="jb_ln_list_sid_li_img">
       <div class="jb_ln_list_sid_li_txt">According to closed source code, iOS only functions</div>
    </a>
    <a href="#" class="jb_ln_list_sid_li">
       <img src="assets/images/learn-img.jpg" class="jb_ln_list_sid_li_img">
       <div class="jb_ln_list_sid_li_txt">According to closed source code, iOS only functions</div>
    </a>
    <a href="#" class="jb_ln_list_sid_li">
       <img src="assets/images/learn-img.jpg" class="jb_ln_list_sid_li_img">
       <div class="jb_ln_list_sid_li_txt">According to closed source code, iOS only functions</div>
    </a>
    <a href="#" class="jb_ln_list_sid_li">
       <img src="assets/images/learn-img.jpg" class="jb_ln_list_sid_li_img">
       <div class="jb_ln_list_sid_li_txt">According to closed source code, iOS only functions</div>
    </a>
 


    </div>
</div>
</div>
    </div>

  </div>

<?php 
$this->load->view('front/common/footer');
?>  